import { Component, OnInit } from '@angular/core';
import { MyEventService } from '../myEvent.service';

@Component({
  selector: 'app-list-events',
  templateUrl: './list-events.component.html',
  styleUrls: ['./list-events.component.css']
})
export class ListEventsComponent implements OnInit {

  public myEvents;
      
    //initialize the call using MyEventService
    constructor(private _myService: MyEventService) { }

      ngOnInit() {
        this.getMyEvent();
      }
    
      getMyEvent() {
        this._myService.getMyEvent().subscribe(
          data => { this.myEvents = data},
          err => console.error(err),
          () => console.log('finished loading')
        );
      }

      onDelete(myEventId: string) {
        this._myService.deleteMyEvent(myEventId);
      }

}
