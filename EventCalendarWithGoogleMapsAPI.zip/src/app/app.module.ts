import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { ProfileEditorComponent } from './profile-editor/profile-editor.component';
import { WarningMessageComponent } from './warning-message/warning-message.component';
import { SuccessMessageComponent } from './success-message/success-message.component';
import { SelectorComponent } from './selector/selector.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { MyEventService } from './myEvent.service';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input'; 
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatButtonModule } from '@angular/material/button';
import { LayoutModule } from '@angular/cdk/layout';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatListModule } from '@angular/material/list';
import { NewEventFormComponent } from './new-event-form/new-event-form.component';
import { NavigationMenuComponent } from './navigation-menu/navigation-menu.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { ListEventsComponent } from './list-events/list-events.component';
import { AddEventsComponent } from './add-events/add-events.component';
import { Routes, RouterModule } from '@angular/router';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { GoogleMapComponent } from './google-map/google-map.component';

const appRoutes: Routes = [ {
  path: '',                     //default component to display
   component: ListEventsComponent
 },       {
   path: 'addEvents',         //when students added 
   component: NewEventFormComponent
 },       {
   path: 'editEvent/:_id',         //when students edited 
   component: NewEventFormComponent
},        {
   path: 'listEvents',       //when students listed
   component: ListEventsComponent
 },       {
   path: '**',                 //when path cannot be found
   component: NotFoundComponent
 }
];


@NgModule({
  declarations: [
    AppComponent,
    ProfileEditorComponent,
    WarningMessageComponent,
    SuccessMessageComponent,
    SelectorComponent,
    NewEventFormComponent,
    NavigationMenuComponent,
    NotFoundComponent,
    ListEventsComponent,
    AddEventsComponent,
    GoogleMapComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    MatFormFieldModule,
    MatInputModule,
    BrowserAnimationsModule,
    MatButtonModule,
    LayoutModule,
    MatToolbarModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    MatMenuModule,
    RouterModule.forRoot(appRoutes),
    MatTableModule,
    MatPaginatorModule,
    MatSortModule
  ],
  providers: [MyEventService],
  bootstrap: [AppComponent]
})
export class AppModule { }
