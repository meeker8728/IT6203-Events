import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-selector',
  templateUrl: './selector.component.html',
  styleUrls: ['./selector.component.css']
})
export class SelectorComponent implements OnInit {

  constructor() { }

  clicked = false;
  buttonName = "Submit Comment!";

  buttonClicked(){
    this.clicked = true;
    this.buttonName = 'Submitted';
 }

 buttonOnMouseOver(){
  console.log('Press the button');
}

inputField(){}

  ngOnInit(): void {
  }

}
