import { Component, OnInit, Input } from '@angular/core';
import { MyEventService } from '../myEvent.service';
import {Router} from '@angular/router';
import {ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-new-event-form',
  templateUrl: './new-event-form.component.html',
  styleUrls: ['./new-event-form.component.css']
})

export class NewEventFormComponent implements OnInit {
  @Input() eventTitle: string;
  @Input() street: string;
  @Input() city: string;
  @Input() state: string;
  @Input() zip: string;
  @Input() date: string;
  @Input() startTime: string;
  @Input() endTime: string;

  public mode = 'Add'; //default mode
  private id: string; //student ID

  constructor(private _myService: MyEventService, private router:Router, public route: ActivatedRoute) {}
  
  onSubmit(){
    console.log("You submitted: " + this.eventTitle + " " + this.street + " " + this.city + " " + this.state + " " + this.zip + " " + this.date + " " + this.startTime + " " + this.endTime);
    if(this.mode == 'Add')
      this._myService.addMyEvent(this.eventTitle, this.street, this.city, this.state, this.zip, this.date, this.startTime, this.endTime);
      if(this.mode == 'Edit')
      this._myService.updateMyEvent(this.id, this.eventTitle, this.street, this.city, this.state, this.zip, this.date, this.startTime, this.endTime);
      this.router.navigate(['/listEvents']);
  }

  ngOnInit() {
    this.route.paramMap.subscribe((paramMap: ParamMap ) => {
      if (paramMap.has('_id'))
        { this.mode = 'Edit'; /*request had a parameter _id */ 
          this.id = paramMap.get('_id');}
      else {this.mode = 'Add';
          this.id = null; }
    });
 
  }

}
