import {Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
//we know that response will be in JSON format
const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
 
@Injectable()
export class MyEventService {
 
    constructor(private http:HttpClient) {}
 
    // Uses http.get() to load data 
    getMyEvent() {
        return this.http.get('http://localhost:8000/myEvent');
    }

    // Uses http.post() to post data 
    addMyEvent(eventTitle: string, street: string, city: string, state: string, zip: string, date: string, startTime: string, endTime: string) {
        this.http.post('http://localhost:8000/myEvent',{ eventTitle, street, city, state, zip, date, startTime, endTime })
      .subscribe((responseData) => {
         console.log(responseData);
       }); 
    
    }

    deleteMyEvent(myEventId: string) {
        this.http.delete("http://localhost:8000/myEvent/" + myEventId)
          .subscribe(() => {
              console.log('Deleted: ' + myEventId);
          });
           
      }

    updateMyEvent(myEventId: string, eventTitle: string, street: string, city: string, state: string, zip: string, date: string, startTime: string, endTime: string) {
        //request path http://localhost:8000/students/5xbd456xx 
        //first and last names will be send as HTTP body parameters 
            this.http.put("http://localhost:8000/myEvent/" 
                 + myEventId,{ eventTitle, street, city, state, zip, date, startTime, endTime })
              .subscribe(() => {
                  console.log('Updated: ' + myEventId);
              });
              
        }
    
    

}
